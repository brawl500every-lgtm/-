import mysql from 'mysql2/promise';

const connection = await mysql.createConnection(process.env.DATABASE_URL);

// Clear existing data
await connection.query('DELETE FROM shipmentItems');
await connection.query('DELETE FROM shipments');
await connection.query('DELETE FROM orderItems');
await connection.query('DELETE FROM orders');
await connection.query('DELETE FROM inventory');
await connection.query('DELETE FROM products');
await connection.query('DELETE FROM suppliers');
await connection.query('DELETE FROM warehouses');
await connection.query('DELETE FROM clients');

// Insert Suppliers
const suppliers = [
  { name: 'ООО Поставщик №1', contactPerson: 'Иван Петров', email: 'ivan@supplier1.ru', phone: '+7-999-111-1111', address: 'ул. Ленина, 10', city: 'Москва' },
  { name: 'ООО Поставщик №2', contactPerson: 'Мария Сидорова', email: 'maria@supplier2.ru', phone: '+7-999-222-2222', address: 'ул. Красная, 25', city: 'Санкт-Петербург' },
  { name: 'ООО Поставщик №3', contactPerson: 'Петр Иванов', email: 'petr@supplier3.ru', phone: '+7-999-333-3333', address: 'ул. Советская, 5', city: 'Казань' },
];

const supplierResults = [];
for (const supplier of suppliers) {
  const [result] = await connection.query('INSERT INTO suppliers SET ?', supplier);
  supplierResults.push(result.insertId);
}

// Insert Warehouses
const warehouses = [
  { name: 'Главный склад', address: 'ул. Промышленная, 1', city: 'Москва', capacity: 10000 },
  { name: 'Склад №2', address: 'ул. Логистическая, 15', city: 'Санкт-Петербург', capacity: 5000 },
  { name: 'Региональный склад', address: 'ул. Торговая, 8', city: 'Казань', capacity: 3000 },
];

const warehouseResults = [];
for (const warehouse of warehouses) {
  const [result] = await connection.query('INSERT INTO warehouses SET ?', warehouse);
  warehouseResults.push(result.insertId);
}

// Insert Clients
const clients = [
  { firstName: 'Алексей', lastName: 'Смирнов', email: 'alexey@example.com', phone: '+7-999-444-4444', address: 'ул. Пушкина, 10', city: 'Москва', postalCode: '101000' },
  { firstName: 'Елена', lastName: 'Волкова', email: 'elena@example.com', phone: '+7-999-555-5555', address: 'ул. Толстого, 20', city: 'Санкт-Петербург', postalCode: '190000' },
  { firstName: 'Дмитрий', lastName: 'Кузнецов', email: 'dmitry@example.com', phone: '+7-999-666-6666', address: 'ул. Горького, 5', city: 'Казань', postalCode: '420000' },
  { firstName: 'Ольга', lastName: 'Морозова', email: 'olga@example.com', phone: '+7-999-777-7777', address: 'ул. Чехова, 30', city: 'Москва', postalCode: '101001' },
  { firstName: 'Сергей', lastName: 'Петров', email: 'sergey@example.com', phone: '+7-999-888-8888', address: 'ул. Достоевского, 12', city: 'Санкт-Петербург', postalCode: '190001' },
];

const clientResults = [];
for (const client of clients) {
  const [result] = await connection.query('INSERT INTO clients SET ?', client);
  clientResults.push(result.insertId);
}

// Insert Products
const products = [
  { name: 'Ноутбук Dell XPS 13', description: 'Портативный ноутбук с процессором Intel', price: 100000, unit: 'шт', supplierId: supplierResults[0] },
  { name: 'Монитор LG 27"', description: '4K монитор для профессиональной работы', price: 35000, unit: 'шт', supplierId: supplierResults[0] },
  { name: 'Клавиатура Mechanical', description: 'Механическая клавиатура RGB', price: 8000, unit: 'шт', supplierId: supplierResults[1] },
  { name: 'Мышь Logitech', description: 'Беспроводная мышь с точной навигацией', price: 3000, unit: 'шт', supplierId: supplierResults[1] },
  { name: 'USB-C кабель', description: 'Кабель для зарядки и передачи данных', price: 500, unit: 'шт', supplierId: supplierResults[2] },
  { name: 'Внешний SSD 1TB', description: 'Портативный твердотельный накопитель', price: 15000, unit: 'шт', supplierId: supplierResults[2] },
  { name: 'Веб-камера HD', description: 'HD веб-камера для видеоконференций', price: 4000, unit: 'шт', supplierId: supplierResults[0] },
  { name: 'Наушники Bluetooth', description: 'Беспроводные наушники с шумоподавлением', price: 6000, unit: 'шт', supplierId: supplierResults[1] },
];

const productResults = [];
for (const product of products) {
  const [result] = await connection.query('INSERT INTO products SET ?', product);
  productResults.push(result.insertId);
}

// Insert Inventory
const inventoryData = [
  { productId: productResults[0], warehouseId: warehouseResults[0], quantity: 50 },
  { productId: productResults[1], warehouseId: warehouseResults[0], quantity: 120 },
  { productId: productResults[2], warehouseId: warehouseResults[1], quantity: 200 },
  { productId: productResults[3], warehouseId: warehouseResults[1], quantity: 300 },
  { productId: productResults[4], warehouseId: warehouseResults[2], quantity: 1000 },
  { productId: productResults[5], warehouseId: warehouseResults[0], quantity: 75 },
  { productId: productResults[6], warehouseId: warehouseResults[1], quantity: 150 },
  { productId: productResults[7], warehouseId: warehouseResults[2], quantity: 250 },
  { productId: productResults[0], warehouseId: warehouseResults[1], quantity: 30 },
  { productId: productResults[1], warehouseId: warehouseResults[2], quantity: 80 },
];

for (const inv of inventoryData) {
  await connection.query('INSERT INTO inventory SET ?', inv);
}

// Insert Orders
const orders = [
  { clientId: clientResults[0], status: 'delivered', totalAmount: 135000, notes: 'Срочная доставка' },
  { clientId: clientResults[1], status: 'shipped', totalAmount: 47000, notes: '' },
  { clientId: clientResults[2], status: 'confirmed', totalAmount: 18000, notes: 'Оплачено' },
  { clientId: clientResults[3], status: 'pending', totalAmount: 9000, notes: 'Ожидание подтверждения' },
  { clientId: clientResults[4], status: 'delivered', totalAmount: 25000, notes: 'Доставлено вовремя' },
];

const orderResults = [];
for (const order of orders) {
  const [result] = await connection.query('INSERT INTO orders SET ?', order);
  orderResults.push(result.insertId);
}

// Insert Order Items
const orderItems = [
  { orderId: orderResults[0], productId: productResults[0], quantity: 1, pricePerUnit: 100000, subtotal: 100000 },
  { orderId: orderResults[0], productId: productResults[1], quantity: 1, pricePerUnit: 35000, subtotal: 35000 },
  { orderId: orderResults[1], productId: productResults[2], quantity: 5, pricePerUnit: 8000, subtotal: 40000 },
  { orderId: orderResults[1], productId: productResults[3], quantity: 1, pricePerUnit: 3000, subtotal: 3000 },
  { orderId: orderResults[2], productId: productResults[4], quantity: 30, pricePerUnit: 500, subtotal: 15000 },
  { orderId: orderResults[2], productId: productResults[5], quantity: 1, pricePerUnit: 15000, subtotal: 15000 },
  { orderId: orderResults[3], productId: productResults[6], quantity: 2, pricePerUnit: 4000, subtotal: 8000 },
  { orderId: orderResults[3], productId: productResults[7], quantity: 1, pricePerUnit: 6000, subtotal: 6000 },
  { orderId: orderResults[4], productId: productResults[0], quantity: 1, pricePerUnit: 100000, subtotal: 100000 },
];

for (const item of orderItems) {
  await connection.query('INSERT INTO orderItems SET ?', item);
}

// Insert Shipments
const shipments = [
  { orderId: orderResults[0], warehouseId: warehouseResults[0], status: 'delivered', trackingNumber: 'TRACK001' },
  { orderId: orderResults[1], warehouseId: warehouseResults[1], status: 'in_transit', trackingNumber: 'TRACK002' },
  { orderId: orderResults[2], warehouseId: warehouseResults[0], status: 'pending', trackingNumber: 'TRACK003' },
  { orderId: orderResults[3], warehouseId: warehouseResults[2], status: 'pending', trackingNumber: 'TRACK004' },
  { orderId: orderResults[4], warehouseId: warehouseResults[1], status: 'delivered', trackingNumber: 'TRACK005' },
];

const shipmentResults = [];
for (const shipment of shipments) {
  const [result] = await connection.query('INSERT INTO shipments SET ?', shipment);
  shipmentResults.push(result.insertId);
}

// Insert Shipment Items
const shipmentItems = [
  { shipmentId: shipmentResults[0], productId: productResults[0], quantity: 1 },
  { shipmentId: shipmentResults[0], productId: productResults[1], quantity: 1 },
  { shipmentId: shipmentResults[1], productId: productResults[2], quantity: 5 },
  { shipmentId: shipmentResults[1], productId: productResults[3], quantity: 1 },
  { shipmentId: shipmentResults[2], productId: productResults[4], quantity: 30 },
  { shipmentId: shipmentResults[3], productId: productResults[6], quantity: 2 },
  { shipmentId: shipmentResults[4], productId: productResults[0], quantity: 1 },
];

for (const item of shipmentItems) {
  await connection.query('INSERT INTO shipmentItems SET ?', item);
}

console.log('✅ Database seeded successfully!');
await connection.end();
