import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, router, protectedProcedure } from "./_core/trpc";
import { z } from "zod";
import * as db from "./db";

export const appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return {
        success: true,
      } as const;
    }),
  }),

  // ============= CLIENTS =============
  clients: router({
    list: publicProcedure.query(() => db.getAllClients()),
    get: publicProcedure.input(z.object({ id: z.number() })).query(({ input }) => db.getClientById(input.id)),
    create: protectedProcedure
      .input(z.object({
        firstName: z.string().min(1),
        lastName: z.string().min(1),
        email: z.string().email(),
        phone: z.string().optional(),
        address: z.string().optional(),
        city: z.string().optional(),
        postalCode: z.string().optional(),
      }))
      .mutation(({ input }) => db.createClient(input)),
    update: protectedProcedure
      .input(z.object({
        id: z.number(),
        firstName: z.string().optional(),
        lastName: z.string().optional(),
        email: z.string().email().optional(),
        phone: z.string().optional(),
        address: z.string().optional(),
        city: z.string().optional(),
        postalCode: z.string().optional(),
      }))
      .mutation(({ input }) => {
        const { id, ...data } = input;
        return db.updateClient(id, data);
      }),
    delete: protectedProcedure.input(z.object({ id: z.number() })).mutation(({ input }) => db.deleteClient(input.id)),
  }),

  // ============= PRODUCTS =============
  products: router({
    list: publicProcedure.query(() => db.getAllProducts()),
    get: publicProcedure.input(z.object({ id: z.number() })).query(({ input }) => db.getProductById(input.id)),
    create: protectedProcedure
      .input(z.object({
        name: z.string().min(1),
        description: z.string().optional(),
        price: z.number().int().min(0),
        unit: z.string().default("шт"),
        supplierId: z.number().optional(),
      }))
      .mutation(({ input }) => db.createProduct(input)),
    update: protectedProcedure
      .input(z.object({
        id: z.number(),
        name: z.string().optional(),
        description: z.string().optional(),
        price: z.number().int().optional(),
        unit: z.string().optional(),
        supplierId: z.number().optional(),
      }))
      .mutation(({ input }) => {
        const { id, ...data } = input;
        return db.updateProduct(id, data);
      }),
    delete: protectedProcedure.input(z.object({ id: z.number() })).mutation(({ input }) => db.deleteProduct(input.id)),
  }),

  // ============= WAREHOUSES =============
  warehouses: router({
    list: publicProcedure.query(() => db.getAllWarehouses()),
    get: publicProcedure.input(z.object({ id: z.number() })).query(({ input }) => db.getWarehouseById(input.id)),
    create: protectedProcedure
      .input(z.object({
        name: z.string().min(1),
        address: z.string().optional(),
        city: z.string().optional(),
        capacity: z.number().int().optional(),
      }))
      .mutation(({ input }) => db.createWarehouse(input)),
    update: protectedProcedure
      .input(z.object({
        id: z.number(),
        name: z.string().optional(),
        address: z.string().optional(),
        city: z.string().optional(),
        capacity: z.number().int().optional(),
      }))
      .mutation(({ input }) => {
        const { id, ...data } = input;
        return db.updateWarehouse(id, data);
      }),
    delete: protectedProcedure.input(z.object({ id: z.number() })).mutation(({ input }) => db.deleteWarehouse(input.id)),
  }),

  // ============= INVENTORY =============
  inventory: router({
    list: publicProcedure.query(() => db.getAllInventory()),
    get: publicProcedure.input(z.object({ id: z.number() })).query(({ input }) => {
      const result = db.getAllInventory();
      return result.then(items => items.find(i => i.id === input.id) || null);
    }),
    create: protectedProcedure
      .input(z.object({
        productId: z.number(),
        warehouseId: z.number(),
        quantity: z.number().int().default(0),
      }))
      .mutation(({ input }) => db.createInventory(input)),
    update: protectedProcedure
      .input(z.object({
        id: z.number(),
        productId: z.number().optional(),
        warehouseId: z.number().optional(),
        quantity: z.number().int().optional(),
      }))
      .mutation(({ input }) => {
        const { id, ...data } = input;
        return db.updateInventory(id, data);
      }),
    delete: protectedProcedure.input(z.object({ id: z.number() })).mutation(({ input }) => db.deleteInventory(input.id)),
  }),

  // ============= SUPPLIERS =============
  suppliers: router({
    list: publicProcedure.query(() => db.getAllSuppliers()),
    get: publicProcedure.input(z.object({ id: z.number() })).query(({ input }) => db.getSupplierById(input.id)),
    create: protectedProcedure
      .input(z.object({
        name: z.string().min(1),
        contactPerson: z.string().optional(),
        email: z.string().email().optional(),
        phone: z.string().optional(),
        address: z.string().optional(),
        city: z.string().optional(),
      }))
      .mutation(({ input }) => db.createSupplier(input)),
    update: protectedProcedure
      .input(z.object({
        id: z.number(),
        name: z.string().optional(),
        contactPerson: z.string().optional(),
        email: z.string().email().optional(),
        phone: z.string().optional(),
        address: z.string().optional(),
        city: z.string().optional(),
      }))
      .mutation(({ input }) => {
        const { id, ...data } = input;
        return db.updateSupplier(id, data);
      }),
    delete: protectedProcedure.input(z.object({ id: z.number() })).mutation(({ input }) => db.deleteSupplier(input.id)),
  }),

  // ============= ORDERS =============
  orders: router({
    list: publicProcedure.query(() => db.getAllOrders()),
    get: publicProcedure.input(z.object({ id: z.number() })).query(({ input }) => db.getOrderById(input.id)),
    create: protectedProcedure
      .input(z.object({
        clientId: z.number(),
        status: z.enum(["pending", "confirmed", "shipped", "delivered", "cancelled"]).default("pending"),
        totalAmount: z.number().int().default(0),
        notes: z.string().optional(),
      }))
      .mutation(({ input }) => db.createOrder(input)),
    update: protectedProcedure
      .input(z.object({
        id: z.number(),
        clientId: z.number().optional(),
        status: z.enum(["pending", "confirmed", "shipped", "delivered", "cancelled"]).optional(),
        totalAmount: z.number().int().optional(),
        notes: z.string().optional(),
      }))
      .mutation(({ input }) => {
        const { id, ...data } = input;
        return db.updateOrder(id, data);
      }),
    delete: protectedProcedure.input(z.object({ id: z.number() })).mutation(({ input }) => db.deleteOrder(input.id)),
  }),

  // ============= ORDER ITEMS =============
  orderItems: router({
    list: publicProcedure.query(() => db.getAllOrderItems()),
    listByOrder: publicProcedure.input(z.object({ orderId: z.number() })).query(({ input }) => db.getOrderItemsByOrderId(input.orderId)),
    create: protectedProcedure
      .input(z.object({
        orderId: z.number(),
        productId: z.number(),
        quantity: z.number().int().min(1),
        pricePerUnit: z.number().int().min(0),
        subtotal: z.number().int().min(0),
      }))
      .mutation(({ input }) => db.createOrderItem(input)),
    update: protectedProcedure
      .input(z.object({
        id: z.number(),
        orderId: z.number().optional(),
        productId: z.number().optional(),
        quantity: z.number().int().optional(),
        pricePerUnit: z.number().int().optional(),
        subtotal: z.number().int().optional(),
      }))
      .mutation(({ input }) => {
        const { id, ...data } = input;
        return db.updateOrderItem(id, data);
      }),
    delete: protectedProcedure.input(z.object({ id: z.number() })).mutation(({ input }) => db.deleteOrderItem(input.id)),
  }),

  // ============= SHIPMENTS =============
  shipments: router({
    list: publicProcedure.query(() => db.getAllShipments()),
    get: publicProcedure.input(z.object({ id: z.number() })).query(({ input }) => db.getShipmentById(input.id)),
    create: protectedProcedure
      .input(z.object({
        orderId: z.number(),
        warehouseId: z.number(),
        status: z.enum(["pending", "in_transit", "delivered"]).default("pending"),
        trackingNumber: z.string().optional(),
      }))
      .mutation(({ input }) => db.createShipment(input)),
    update: protectedProcedure
      .input(z.object({
        id: z.number(),
        orderId: z.number().optional(),
        warehouseId: z.number().optional(),
        status: z.enum(["pending", "in_transit", "delivered"]).optional(),
        trackingNumber: z.string().optional(),
      }))
      .mutation(({ input }) => {
        const { id, ...data } = input;
        return db.updateShipment(id, data);
      }),
    delete: protectedProcedure.input(z.object({ id: z.number() })).mutation(({ input }) => db.deleteShipment(input.id)),
  }),

  // ============= SHIPMENT ITEMS =============
  shipmentItems: router({
    list: publicProcedure.query(() => db.getAllShipmentItems()),
    listByShipment: publicProcedure.input(z.object({ shipmentId: z.number() })).query(({ input }) => db.getShipmentItemsByShipmentId(input.shipmentId)),
    create: protectedProcedure
      .input(z.object({
        shipmentId: z.number(),
        productId: z.number(),
        quantity: z.number().int().min(1),
      }))
      .mutation(({ input }) => db.createShipmentItem(input)),
    update: protectedProcedure
      .input(z.object({
        id: z.number(),
        shipmentId: z.number().optional(),
        productId: z.number().optional(),
        quantity: z.number().int().optional(),
      }))
      .mutation(({ input }) => {
        const { id, ...data } = input;
        return db.updateShipmentItem(id, data);
      }),
    delete: protectedProcedure.input(z.object({ id: z.number() })).mutation(({ input }) => db.deleteShipmentItem(input.id)),
  }),
});

export type AppRouter = typeof appRouter;
