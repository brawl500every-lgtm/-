import { useState } from "react";
import { useLocation } from "wouter";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { ArrowLeft, Plus, Edit2, Trash2, Loader2 } from "lucide-react";
import { motion } from "framer-motion";
import { toast } from "sonner";

export default function Orders() {
  const [, setLocation] = useLocation();
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [editingId, setEditingId] = useState<number | null>(null);
  const [formData, setFormData] = useState({
    clientId: 0,
    status: "pending" as const,
    totalAmount: 0,
    notes: "",
  });

  const ordersQuery = trpc.orders.list.useQuery();
  const clientsQuery = trpc.clients.list.useQuery();
  const createMutation = trpc.orders.create.useMutation();
  const updateMutation = trpc.orders.update.useMutation();
  const deleteMutation = trpc.orders.delete.useMutation();

  const handleOpenDialog = (order?: any) => {
    if (order) {
      setEditingId(order.id);
      setFormData(order);
    } else {
      setEditingId(null);
      setFormData({
        clientId: 0,
        status: "pending",
        totalAmount: 0,
        notes: "",
      });
    }
    setIsDialogOpen(true);
  };

  const handleSave = async () => {
    try {
      if (editingId) {
        await updateMutation.mutateAsync({ id: editingId, ...formData });
        toast.success("Заказ обновлен");
      } else {
        await createMutation.mutateAsync(formData);
        toast.success("Заказ добавлен");
      }
      setIsDialogOpen(false);
      ordersQuery.refetch();
    } catch (error) {
      toast.error("Ошибка при сохранении");
    }
  };

  const handleDelete = async (id: number) => {
    if (confirm("Вы уверены?")) {
      try {
        await deleteMutation.mutateAsync({ id });
        toast.success("Заказ удален");
        ordersQuery.refetch();
      } catch (error) {
        toast.error("Ошибка при удалении");
      }
    }
  };

  const getClientName = (id: number) => {
    const client = clientsQuery.data?.find(c => c.id === id);
    return client ? `${client.firstName} ${client.lastName}` : "-";
  };

  const formatPrice = (price: number) => {
    return (price / 100).toFixed(2) + " ₽";
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case "pending":
        return "text-yellow-400";
      case "confirmed":
        return "text-blue-400";
      case "shipped":
        return "text-purple-400";
      case "delivered":
        return "text-green-400";
      case "cancelled":
        return "text-red-400";
      default:
        return "text-slate-400";
    }
  };

  const getStatusLabel = (status: string) => {
    const labels: Record<string, string> = {
      pending: "Ожидание",
      confirmed: "Подтвержден",
      shipped: "Отправлен",
      delivered: "Доставлен",
      cancelled: "Отменен",
    };
    return labels[status] || status;
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900">
      {/* Header */}
      <header className="border-b border-slate-700 bg-slate-800/50 backdrop-blur">
        <div className="container mx-auto px-4 py-4 flex items-center gap-4">
          <Button
            variant="ghost"
            size="icon"
            onClick={() => setLocation("/dashboard")}
            className="text-slate-300 hover:text-white"
          >
            <ArrowLeft className="w-5 h-5" />
          </Button>
          <h1 className="text-2xl font-bold text-white">Управление Заказами</h1>
        </div>
      </header>

      <div className="container mx-auto px-4 py-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
        >
          <Card className="bg-slate-800 border-slate-700">
            <CardHeader className="flex flex-row items-center justify-between">
              <div>
                <CardTitle className="text-white">Заказы</CardTitle>
                <CardDescription className="text-slate-400">
                  Всего заказов: {ordersQuery.data?.length || 0}
                </CardDescription>
              </div>
              <Button onClick={() => handleOpenDialog()} className="gap-2">
                <Plus className="w-4 h-4" />
                Добавить заказ
              </Button>
            </CardHeader>
            <CardContent>
              {ordersQuery.isLoading ? (
                <div className="flex items-center justify-center py-8">
                  <Loader2 className="w-6 h-6 animate-spin text-slate-400" />
                </div>
              ) : (
                <div className="overflow-x-auto">
                  <table className="w-full text-sm">
                    <thead>
                      <tr className="border-b border-slate-700">
                        <th className="text-left py-3 px-4 font-semibold text-slate-300">ID</th>
                        <th className="text-left py-3 px-4 font-semibold text-slate-300">Клиент</th>
                        <th className="text-left py-3 px-4 font-semibold text-slate-300">Сумма</th>
                        <th className="text-left py-3 px-4 font-semibold text-slate-300">Статус</th>
                        <th className="text-left py-3 px-4 font-semibold text-slate-300">Дата</th>
                        <th className="text-right py-3 px-4 font-semibold text-slate-300">Действия</th>
                      </tr>
                    </thead>
                    <tbody>
                      {ordersQuery.data?.map((order, index) => (
                        <motion.tr
                          key={order.id}
                          initial={{ opacity: 0, x: -20 }}
                          animate={{ opacity: 1, x: 0 }}
                          transition={{ duration: 0.3, delay: index * 0.05 }}
                          className="border-b border-slate-700 hover:bg-slate-700/50 transition-colors"
                        >
                          <td className="py-3 px-4 text-slate-200">#{order.id}</td>
                          <td className="py-3 px-4 text-slate-400">{getClientName(order.clientId)}</td>\n                          <td className="py-3 px-4 text-slate-400">{formatPrice(order.totalAmount)}</td>
                          <td className={`py-3 px-4 font-semibold ${getStatusColor(order.status)}`}>
                            {getStatusLabel(order.status)}
                          </td>
                          <td className="py-3 px-4 text-slate-400">
                            {new Date(order.orderDate).toLocaleDateString("ru-RU")}
                          </td>
                          <td className="py-3 px-4 text-right space-x-2">
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => handleOpenDialog(order)}
                              className="text-blue-400 hover:text-blue-300"
                            >
                              <Edit2 className="w-4 h-4" />
                            </Button>
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => handleDelete(order.id)}
                              className="text-red-400 hover:text-red-300"
                            >
                              <Trash2 className="w-4 h-4" />
                            </Button>
                          </td>
                        </motion.tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
            </CardContent>
          </Card>
        </motion.div>
      </div>

      {/* Dialog */}
      <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
        <DialogContent className="bg-slate-800 border-slate-700">
          <DialogHeader>
            <DialogTitle className="text-white">
              {editingId ? "Редактировать заказ" : "Добавить заказ"}
            </DialogTitle>
            <DialogDescription className="text-slate-400">
              Заполните информацию о заказе
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <Label className="text-slate-300">Клиент</Label>
              <Select value={String(formData.clientId)} onValueChange={(v) => setFormData({ ...formData, clientId: parseInt(v) })}>
                <SelectTrigger className="bg-slate-700 border-slate-600 text-white">
                  <SelectValue placeholder="Выберите клиента" />
                </SelectTrigger>
                <SelectContent className="bg-slate-700 border-slate-600">
                  {clientsQuery.data?.map((client) => (
                    <SelectItem key={client.id} value={String(client.id)} className="text-white">
                      {client.firstName} {client.lastName}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label className="text-slate-300">Статус</Label>
              <Select value={formData.status} onValueChange={(v: any) => setFormData({ ...formData, status: v })}>
                <SelectTrigger className="bg-slate-700 border-slate-600 text-white">
                  <SelectValue placeholder="Выберите статус" />
                </SelectTrigger>
                <SelectContent className="bg-slate-700 border-slate-600">
                  <SelectItem value="pending" className="text-white">Ожидание</SelectItem>
                  <SelectItem value="confirmed" className="text-white">Подтвержден</SelectItem>
                  <SelectItem value="shipped" className="text-white">Отправлен</SelectItem>
                  <SelectItem value="delivered" className="text-white">Доставлен</SelectItem>
                  <SelectItem value="cancelled" className="text-white">Отменен</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label className="text-slate-300">Сумма (₽)</Label>
              <Input
                type="number"
                value={formData.totalAmount / 100}
                onChange={(e) => setFormData({ ...formData, totalAmount: Math.round(parseFloat(e.target.value) * 100) })}
                className="bg-slate-700 border-slate-600 text-white"
                placeholder="0.00"
              />
            </div>
            <div>
              <Label className="text-slate-300">Примечания</Label>
              <Input
                value={formData.notes}
                onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
                className="bg-slate-700 border-slate-600 text-white"
                placeholder="Примечания"
              />
            </div>
            <div className="flex gap-3 justify-end">
              <Button variant="outline" onClick={() => setIsDialogOpen(false)}>
                Отмена
              </Button>
              <Button onClick={handleSave} disabled={createMutation.isPending || updateMutation.isPending}>
                {createMutation.isPending || updateMutation.isPending ? (
                  <>
                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                    Сохранение...
                  </>
                ) : (
                  "Сохранить"
                )}
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
