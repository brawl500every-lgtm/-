import { useState } from "react";
import { useLocation } from "wouter";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { ArrowLeft, Plus, Edit2, Trash2, Loader2 } from "lucide-react";
import { motion } from "framer-motion";
import { toast } from "sonner";

export default function Warehouses() {
  const [, setLocation] = useLocation();
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [editingId, setEditingId] = useState<number | null>(null);
  const [formData, setFormData] = useState({
    name: "",
    address: "",
    city: "",
    capacity: 0,
  });

  const warehousesQuery = trpc.warehouses.list.useQuery();
  const createMutation = trpc.warehouses.create.useMutation();
  const updateMutation = trpc.warehouses.update.useMutation();
  const deleteMutation = trpc.warehouses.delete.useMutation();

  const handleOpenDialog = (warehouse?: any) => {
    if (warehouse) {
      setEditingId(warehouse.id);
      setFormData(warehouse);
    } else {
      setEditingId(null);
      setFormData({
        name: "",
        address: "",
        city: "",
        capacity: 0,
      });
    }
    setIsDialogOpen(true);
  };

  const handleSave = async () => {
    try {
      if (editingId) {
        await updateMutation.mutateAsync({ id: editingId, ...formData });
        toast.success("Склад обновлен");
      } else {
        await createMutation.mutateAsync(formData);
        toast.success("Склад добавлен");
      }
      setIsDialogOpen(false);
      warehousesQuery.refetch();
    } catch (error) {
      toast.error("Ошибка при сохранении");
    }
  };

  const handleDelete = async (id: number) => {
    if (confirm("Вы уверены?")) {
      try {
        await deleteMutation.mutateAsync({ id });
        toast.success("Склад удален");
        warehousesQuery.refetch();
      } catch (error) {
        toast.error("Ошибка при удалении");
      }
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900">
      {/* Header */}
      <header className="border-b border-slate-700 bg-slate-800/50 backdrop-blur">
        <div className="container mx-auto px-4 py-4 flex items-center gap-4">
          <Button
            variant="ghost"
            size="icon"
            onClick={() => setLocation("/dashboard")}
            className="text-slate-300 hover:text-white"
          >
            <ArrowLeft className="w-5 h-5" />
          </Button>
          <h1 className="text-2xl font-bold text-white">Управление Складами</h1>
        </div>
      </header>

      <div className="container mx-auto px-4 py-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
        >
          <Card className="bg-slate-800 border-slate-700">
            <CardHeader className="flex flex-row items-center justify-between">
              <div>
                <CardTitle className="text-white">Склады</CardTitle>
                <CardDescription className="text-slate-400">
                  Всего складов: {warehousesQuery.data?.length || 0}
                </CardDescription>
              </div>
              <Button onClick={() => handleOpenDialog()} className="gap-2">
                <Plus className="w-4 h-4" />
                Добавить склад
              </Button>
            </CardHeader>
            <CardContent>
              {warehousesQuery.isLoading ? (
                <div className="flex items-center justify-center py-8">
                  <Loader2 className="w-6 h-6 animate-spin text-slate-400" />
                </div>
              ) : (
                <div className="overflow-x-auto">
                  <table className="w-full text-sm">
                    <thead>
                      <tr className="border-b border-slate-700">
                        <th className="text-left py-3 px-4 font-semibold text-slate-300">Название</th>
                        <th className="text-left py-3 px-4 font-semibold text-slate-300">Город</th>
                        <th className="text-left py-3 px-4 font-semibold text-slate-300">Адрес</th>
                        <th className="text-left py-3 px-4 font-semibold text-slate-300">Вместимость</th>
                        <th className="text-right py-3 px-4 font-semibold text-slate-300">Действия</th>
                      </tr>
                    </thead>
                    <tbody>
                      {warehousesQuery.data?.map((warehouse, index) => (
                        <motion.tr
                          key={warehouse.id}
                          initial={{ opacity: 0, x: -20 }}
                          animate={{ opacity: 1, x: 0 }}
                          transition={{ duration: 0.3, delay: index * 0.05 }}
                          className="border-b border-slate-700 hover:bg-slate-700/50 transition-colors"
                        >
                          <td className="py-3 px-4 text-slate-200">{warehouse.name}</td>
                          <td className="py-3 px-4 text-slate-400">{warehouse.city || "-"}</td>
                          <td className="py-3 px-4 text-slate-400">{warehouse.address || "-"}</td>
                          <td className="py-3 px-4 text-slate-400">{warehouse.capacity || "-"}</td>
                          <td className="py-3 px-4 text-right space-x-2">
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => handleOpenDialog(warehouse)}
                              className="text-blue-400 hover:text-blue-300"
                            >
                              <Edit2 className="w-4 h-4" />
                            </Button>
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => handleDelete(warehouse.id)}
                              className="text-red-400 hover:text-red-300"
                            >
                              <Trash2 className="w-4 h-4" />
                            </Button>
                          </td>
                        </motion.tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
            </CardContent>
          </Card>
        </motion.div>
      </div>

      {/* Dialog */}
      <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
        <DialogContent className="bg-slate-800 border-slate-700">
          <DialogHeader>
            <DialogTitle className="text-white">
              {editingId ? "Редактировать склад" : "Добавить склад"}
            </DialogTitle>
            <DialogDescription className="text-slate-400">
              Заполните информацию о складе
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <Label className="text-slate-300">Название</Label>
              <Input
                value={formData.name}
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                className="bg-slate-700 border-slate-600 text-white"
                placeholder="Название склада"
              />
            </div>
            <div>
              <Label className="text-slate-300">Адрес</Label>
              <Input
                value={formData.address}
                onChange={(e) => setFormData({ ...formData, address: e.target.value })}
                className="bg-slate-700 border-slate-600 text-white"
                placeholder="Адрес"
              />
            </div>
            <div>
              <Label className="text-slate-300">Город</Label>
              <Input
                value={formData.city}
                onChange={(e) => setFormData({ ...formData, city: e.target.value })}
                className="bg-slate-700 border-slate-600 text-white"
                placeholder="Город"
              />
            </div>
            <div>
              <Label className="text-slate-300">Вместимость</Label>
              <Input
                type="number"
                value={formData.capacity}
                onChange={(e) => setFormData({ ...formData, capacity: parseInt(e.target.value) || 0 })}
                className="bg-slate-700 border-slate-600 text-white"
                placeholder="0"
              />
            </div>
            <div className="flex gap-3 justify-end">
              <Button variant="outline" onClick={() => setIsDialogOpen(false)}>
                Отмена
              </Button>
              <Button onClick={handleSave} disabled={createMutation.isPending || updateMutation.isPending}>
                {createMutation.isPending || updateMutation.isPending ? (
                  <>
                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                    Сохранение...
                  </>
                ) : (
                  "Сохранить"
                )}
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
