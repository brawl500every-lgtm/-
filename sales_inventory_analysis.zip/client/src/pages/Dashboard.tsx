import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { trpc } from "@/lib/trpc";
import { BarChart3, Package, ShoppingCart, Warehouse, Users, TrendingUp, LogOut } from "lucide-react";
import { useLocation } from "wouter";
import { motion } from "framer-motion";

export default function Dashboard() {
  const { user, logout } = useAuth();
  const [, setLocation] = useLocation();

  const clientsQuery = trpc.clients.list.useQuery();
  const productsQuery = trpc.products.list.useQuery();
  const ordersQuery = trpc.orders.list.useQuery();
  const inventoryQuery = trpc.inventory.list.useQuery();
  const warehousesQuery = trpc.warehouses.list.useQuery();

  const handleLogout = async () => {
    await logout();
    setLocation("/");
  };

  const stats = [
    {
      label: "Клиенты",
      value: clientsQuery.data?.length || 0,
      icon: Users,
      color: "from-blue-500 to-blue-600",
      path: "/clients",
    },
    {
      label: "Продукты",
      value: productsQuery.data?.length || 0,
      icon: Package,
      color: "from-purple-500 to-purple-600",
      path: "/products",
    },
    {
      label: "Заказы",
      value: ordersQuery.data?.length || 0,
      icon: ShoppingCart,
      color: "from-orange-500 to-orange-600",
      path: "/orders",
    },
    {
      label: "Запасы",
      value: inventoryQuery.data?.length || 0,
      icon: Warehouse,
      color: "from-green-500 to-green-600",
      path: "/inventory",
    },
    {
      label: "Склады",
      value: warehousesQuery.data?.length || 0,
      icon: BarChart3,
      color: "from-pink-500 to-pink-600",
      path: "/warehouses",
    },
  ];

  const menuItems = [
    { label: "Клиенты", icon: Users, path: "/clients" },
    { label: "Продукты", icon: Package, path: "/products" },
    { label: "Заказы", icon: ShoppingCart, path: "/orders" },
    { label: "Запасы", icon: Warehouse, path: "/inventory" },
    { label: "Склады", icon: BarChart3, path: "/warehouses" },
    { label: "Поставщики", icon: TrendingUp, path: "/suppliers" },
    { label: "Отгрузки", icon: TrendingUp, path: "/shipments" },
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900">
      {/* Header */}
      <header className="border-b border-slate-700 bg-slate-800/50 backdrop-blur">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-gradient-to-br from-blue-500 to-purple-600 rounded-lg flex items-center justify-center">
              <BarChart3 className="w-6 h-6 text-white" />
            </div>
            <h1 className="text-2xl font-bold text-white">Анализ Продаж & Запасов</h1>
          </div>
          <div className="flex items-center gap-4">
            <span className="text-slate-300">{user?.name || "Пользователь"}</span>
            <Button variant="outline" size="sm" onClick={handleLogout} className="gap-2">
              <LogOut className="w-4 h-4" />
              Выход
            </Button>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 py-8">
        {/* Welcome Section */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="mb-8"
        >
          <h2 className="text-3xl font-bold text-white mb-2">Добро пожаловать, {user?.name}!</h2>
          <p className="text-slate-400">Управляйте продажами и запасами в одном месте</p>
        </motion.div>

        {/* Stats Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-4 mb-8">
          {stats.map((stat, index) => {
            const Icon = stat.icon;
            return (
              <motion.div
                key={stat.label}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
              >
                <Card
                  className="cursor-pointer hover:shadow-lg transition-all duration-300 bg-slate-800 border-slate-700 hover:border-slate-600"
                  onClick={() => setLocation(stat.path)}
                >
                  <CardContent className="pt-6">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-slate-400 text-sm mb-1">{stat.label}</p>
                        <p className="text-3xl font-bold text-white">{stat.value}</p>
                      </div>
                      <div className={`bg-gradient-to-br ${stat.color} p-3 rounded-lg`}>
                        <Icon className="w-6 h-6 text-white" />
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            );
          })}
        </div>

        {/* Main Content Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
          {/* Sidebar Menu */}
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.5 }}
          >
            <Card className="bg-slate-800 border-slate-700 sticky top-4">
              <CardHeader>
                <CardTitle className="text-white">Меню</CardTitle>
              </CardHeader>
              <CardContent className="space-y-2">
                {menuItems.map((item) => {
                  const Icon = item.icon;
                  return (
                    <Button
                      key={item.path}
                      variant="ghost"
                      className="w-full justify-start text-slate-300 hover:text-white hover:bg-slate-700"
                      onClick={() => setLocation(item.path)}
                    >
                      <Icon className="w-4 h-4 mr-2" />
                      {item.label}
                    </Button>
                  );
                })}
              </CardContent>
            </Card>
          </motion.div>

          {/* Main Info */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.2 }}
            className="lg:col-span-3"
          >
            <Card className="bg-slate-800 border-slate-700">
              <CardHeader>
                <CardTitle className="text-white">О системе</CardTitle>
                <CardDescription className="text-slate-400">
                  Полнофункциональная система управления продажами и запасами
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="bg-slate-700/50 p-4 rounded-lg border border-slate-600">
                    <h3 className="font-semibold text-white mb-2">Управление Клиентами</h3>
                    <p className="text-slate-400 text-sm">
                      Ведите полную информацию о клиентах, их контактах и адресах доставки.
                    </p>
                  </div>
                  <div className="bg-slate-700/50 p-4 rounded-lg border border-slate-600">
                    <h3 className="font-semibold text-white mb-2">Каталог Продуктов</h3>
                    <p className="text-slate-400 text-sm">
                      Управляйте каталогом товаров с ценами, описанием и поставщиками.
                    </p>
                  </div>
                  <div className="bg-slate-700/50 p-4 rounded-lg border border-slate-600">
                    <h3 className="font-semibold text-white mb-2">Управление Заказами</h3>
                    <p className="text-slate-400 text-sm">
                      Создавайте и отслеживайте заказы клиентов с полной историей.
                    </p>
                  </div>
                  <div className="bg-slate-700/50 p-4 rounded-lg border border-slate-600">
                    <h3 className="font-semibold text-white mb-2">Контроль Запасов</h3>
                    <p className="text-slate-400 text-sm">
                      Мониторьте уровни запасов на разных складах в реальном времени.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        </div>
      </div>
    </div>
  );
}
