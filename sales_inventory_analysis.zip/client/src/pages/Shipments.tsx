import { useState } from "react";
import { useLocation } from "wouter";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { ArrowLeft, Plus, Edit2, Trash2, Loader2 } from "lucide-react";
import { motion } from "framer-motion";
import { toast } from "sonner";

export default function Shipments() {
  const [, setLocation] = useLocation();
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [editingId, setEditingId] = useState<number | null>(null);
  const [formData, setFormData] = useState({
    orderId: 0,
    warehouseId: 0,
    status: "pending" as const,
    trackingNumber: "",
  });

  const shipmentsQuery = trpc.shipments.list.useQuery();
  const ordersQuery = trpc.orders.list.useQuery();
  const warehousesQuery = trpc.warehouses.list.useQuery();
  const createMutation = trpc.shipments.create.useMutation();
  const updateMutation = trpc.shipments.update.useMutation();
  const deleteMutation = trpc.shipments.delete.useMutation();

  const handleOpenDialog = (shipment?: any) => {
    if (shipment) {
      setEditingId(shipment.id);
      setFormData(shipment);
    } else {
      setEditingId(null);
      setFormData({
        orderId: 0,
        warehouseId: 0,
        status: "pending",
        trackingNumber: "",
      });
    }
    setIsDialogOpen(true);
  };

  const handleSave = async () => {
    try {
      if (editingId) {
        await updateMutation.mutateAsync({ id: editingId, ...formData });
        toast.success("Отгрузка обновлена");
      } else {
        await createMutation.mutateAsync(formData);
        toast.success("Отгрузка добавлена");
      }
      setIsDialogOpen(false);
      shipmentsQuery.refetch();
    } catch (error) {
      toast.error("Ошибка при сохранении");
    }
  };

  const handleDelete = async (id: number) => {
    if (confirm("Вы уверены?")) {
      try {
        await deleteMutation.mutateAsync({ id });
        toast.success("Отгрузка удалена");
        shipmentsQuery.refetch();
      } catch (error) {
        toast.error("Ошибка при удалении");
      }
    }
  };

  const getOrderId = (id: number) => {
    return ordersQuery.data?.find(o => o.id === id)?.id || "-";
  };

  const getWarehouseName = (id: number) => {
    return warehousesQuery.data?.find(w => w.id === id)?.name || "-";
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case "pending":
        return "text-yellow-400";
      case "in_transit":
        return "text-blue-400";
      case "delivered":
        return "text-green-400";
      default:
        return "text-slate-400";
    }
  };

  const getStatusLabel = (status: string) => {
    const labels: Record<string, string> = {
      pending: "Ожидание",
      in_transit: "В пути",
      delivered: "Доставлена",
    };
    return labels[status] || status;
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900">
      {/* Header */}
      <header className="border-b border-slate-700 bg-slate-800/50 backdrop-blur">
        <div className="container mx-auto px-4 py-4 flex items-center gap-4">
          <Button
            variant="ghost"
            size="icon"
            onClick={() => setLocation("/dashboard")}
            className="text-slate-300 hover:text-white"
          >
            <ArrowLeft className="w-5 h-5" />
          </Button>
          <h1 className="text-2xl font-bold text-white">Управление Отгрузками</h1>
        </div>
      </header>

      <div className="container mx-auto px-4 py-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
        >
          <Card className="bg-slate-800 border-slate-700">
            <CardHeader className="flex flex-row items-center justify-between">
              <div>
                <CardTitle className="text-white">Отгрузки</CardTitle>
                <CardDescription className="text-slate-400">
                  Всего отгрузок: {shipmentsQuery.data?.length || 0}
                </CardDescription>
              </div>
              <Button onClick={() => handleOpenDialog()} className="gap-2">
                <Plus className="w-4 h-4" />
                Добавить отгрузку
              </Button>
            </CardHeader>
            <CardContent>
              {shipmentsQuery.isLoading ? (
                <div className="flex items-center justify-center py-8">
                  <Loader2 className="w-6 h-6 animate-spin text-slate-400" />
                </div>
              ) : (
                <div className="overflow-x-auto">
                  <table className="w-full text-sm">
                    <thead>
                      <tr className="border-b border-slate-700">
                        <th className="text-left py-3 px-4 font-semibold text-slate-300">ID</th>
                        <th className="text-left py-3 px-4 font-semibold text-slate-300">Заказ</th>
                        <th className="text-left py-3 px-4 font-semibold text-slate-300">Склад</th>
                        <th className="text-left py-3 px-4 font-semibold text-slate-300">Статус</th>
                        <th className="text-left py-3 px-4 font-semibold text-slate-300">Трекинг</th>
                        <th className="text-right py-3 px-4 font-semibold text-slate-300">Действия</th>
                      </tr>
                    </thead>
                    <tbody>
                      {shipmentsQuery.data?.map((shipment, index) => (
                        <motion.tr
                          key={shipment.id}
                          initial={{ opacity: 0, x: -20 }}
                          animate={{ opacity: 1, x: 0 }}
                          transition={{ duration: 0.3, delay: index * 0.05 }}
                          className="border-b border-slate-700 hover:bg-slate-700/50 transition-colors"
                        >
                          <td className="py-3 px-4 text-slate-200">#{shipment.id}</td>
                          <td className="py-3 px-4 text-slate-400">#{getOrderId(shipment.orderId)}</td>
                          <td className="py-3 px-4 text-slate-400">{getWarehouseName(shipment.warehouseId)}</td>
                          <td className={`py-3 px-4 font-semibold ${getStatusColor(shipment.status)}`}>
                            {getStatusLabel(shipment.status)}
                          </td>
                          <td className="py-3 px-4 text-slate-400">{shipment.trackingNumber || "-"}</td>
                          <td className="py-3 px-4 text-right space-x-2">
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => handleOpenDialog(shipment)}
                              className="text-blue-400 hover:text-blue-300"
                            >
                              <Edit2 className="w-4 h-4" />
                            </Button>
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => handleDelete(shipment.id)}
                              className="text-red-400 hover:text-red-300"
                            >
                              <Trash2 className="w-4 h-4" />
                            </Button>
                          </td>
                        </motion.tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
            </CardContent>
          </Card>
        </motion.div>
      </div>

      {/* Dialog */}
      <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
        <DialogContent className="bg-slate-800 border-slate-700">
          <DialogHeader>
            <DialogTitle className="text-white">
              {editingId ? "Редактировать отгрузку" : "Добавить отгрузку"}
            </DialogTitle>
            <DialogDescription className="text-slate-400">
              Заполните информацию об отгрузке
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <Label className="text-slate-300">Заказ</Label>
              <Select value={String(formData.orderId)} onValueChange={(v) => setFormData({ ...formData, orderId: parseInt(v) })}>
                <SelectTrigger className="bg-slate-700 border-slate-600 text-white">
                  <SelectValue placeholder="Выберите заказ" />
                </SelectTrigger>
                <SelectContent className="bg-slate-700 border-slate-600">
                  {ordersQuery.data?.map((order) => (
                    <SelectItem key={order.id} value={String(order.id)} className="text-white">
                      Заказ #{order.id}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label className="text-slate-300">Склад</Label>
              <Select value={String(formData.warehouseId)} onValueChange={(v) => setFormData({ ...formData, warehouseId: parseInt(v) })}>
                <SelectTrigger className="bg-slate-700 border-slate-600 text-white">
                  <SelectValue placeholder="Выберите склад" />
                </SelectTrigger>
                <SelectContent className="bg-slate-700 border-slate-600">
                  {warehousesQuery.data?.map((warehouse) => (
                    <SelectItem key={warehouse.id} value={String(warehouse.id)} className="text-white">
                      {warehouse.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label className="text-slate-300">Статус</Label>
              <Select value={formData.status} onValueChange={(v: any) => setFormData({ ...formData, status: v })}>
                <SelectTrigger className="bg-slate-700 border-slate-600 text-white">
                  <SelectValue placeholder="Выберите статус" />
                </SelectTrigger>
                <SelectContent className="bg-slate-700 border-slate-600">
                  <SelectItem value="pending" className="text-white">Ожидание</SelectItem>
                  <SelectItem value="in_transit" className="text-white">В пути</SelectItem>
                  <SelectItem value="delivered" className="text-white">Доставлена</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label className="text-slate-300">Номер трекинга</Label>
              <Input
                value={formData.trackingNumber}
                onChange={(e) => setFormData({ ...formData, trackingNumber: e.target.value })}
                className="bg-slate-700 border-slate-600 text-white"
                placeholder="TRACK001"
              />
            </div>
            <div className="flex gap-3 justify-end">
              <Button variant="outline" onClick={() => setIsDialogOpen(false)}>
                Отмена
              </Button>
              <Button onClick={handleSave} disabled={createMutation.isPending || updateMutation.isPending}>
                {createMutation.isPending || updateMutation.isPending ? (
                  <>
                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                    Сохранение...
                  </>
                ) : (
                  "Сохранить"
                )}
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
