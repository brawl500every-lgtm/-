import { useState } from "react";
import { useLocation } from "wouter";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { ArrowLeft, Plus, Edit2, Trash2, Loader2 } from "lucide-react";
import { motion } from "framer-motion";
import { toast } from "sonner";

export default function Inventory() {
  const [, setLocation] = useLocation();
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [editingId, setEditingId] = useState<number | null>(null);
  const [formData, setFormData] = useState({
    productId: 0,
    warehouseId: 0,
    quantity: 0,
  });

  const inventoryQuery = trpc.inventory.list.useQuery();
  const productsQuery = trpc.products.list.useQuery();
  const warehousesQuery = trpc.warehouses.list.useQuery();
  const createMutation = trpc.inventory.create.useMutation();
  const updateMutation = trpc.inventory.update.useMutation();
  const deleteMutation = trpc.inventory.delete.useMutation();

  const handleOpenDialog = (item?: any) => {
    if (item) {
      setEditingId(item.id);
      setFormData(item);
    } else {
      setEditingId(null);
      setFormData({
        productId: 0,
        warehouseId: 0,
        quantity: 0,
      });
    }
    setIsDialogOpen(true);
  };

  const handleSave = async () => {
    try {
      if (editingId) {
        await updateMutation.mutateAsync({ id: editingId, ...formData });
        toast.success("Запас обновлен");
      } else {
        await createMutation.mutateAsync(formData);
        toast.success("Запас добавлен");
      }
      setIsDialogOpen(false);
      inventoryQuery.refetch();
    } catch (error) {
      toast.error("Ошибка при сохранении");
    }
  };

  const handleDelete = async (id: number) => {
    if (confirm("Вы уверены?")) {
      try {
        await deleteMutation.mutateAsync({ id });
        toast.success("Запас удален");
        inventoryQuery.refetch();
      } catch (error) {
        toast.error("Ошибка при удалении");
      }
    }
  };

  const getProductName = (id: number) => {
    return productsQuery.data?.find(p => p.id === id)?.name || "-";
  };

  const getWarehouseName = (id: number) => {
    return warehousesQuery.data?.find(w => w.id === id)?.name || "-";
  };

  const getQuantityColor = (quantity: number) => {
    if (quantity === 0) return "text-red-400";
    if (quantity < 50) return "text-yellow-400";
    return "text-green-400";
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900">
      {/* Header */}
      <header className="border-b border-slate-700 bg-slate-800/50 backdrop-blur">
        <div className="container mx-auto px-4 py-4 flex items-center gap-4">
          <Button
            variant="ghost"
            size="icon"
            onClick={() => setLocation("/dashboard")}
            className="text-slate-300 hover:text-white"
          >
            <ArrowLeft className="w-5 h-5" />
          </Button>
          <h1 className="text-2xl font-bold text-white">Управление Запасами</h1>
        </div>
      </header>

      <div className="container mx-auto px-4 py-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
        >
          <Card className="bg-slate-800 border-slate-700">
            <CardHeader className="flex flex-row items-center justify-between">
              <div>
                <CardTitle className="text-white">Запасы</CardTitle>
                <CardDescription className="text-slate-400">
                  Всего записей: {inventoryQuery.data?.length || 0}
                </CardDescription>
              </div>
              <Button onClick={() => handleOpenDialog()} className="gap-2">
                <Plus className="w-4 h-4" />
                Добавить запас
              </Button>
            </CardHeader>
            <CardContent>
              {inventoryQuery.isLoading ? (
                <div className="flex items-center justify-center py-8">
                  <Loader2 className="w-6 h-6 animate-spin text-slate-400" />
                </div>
              ) : (
                <div className="overflow-x-auto">
                  <table className="w-full text-sm">
                    <thead>
                      <tr className="border-b border-slate-700">
                        <th className="text-left py-3 px-4 font-semibold text-slate-300">Продукт</th>
                        <th className="text-left py-3 px-4 font-semibold text-slate-300">Склад</th>
                        <th className="text-left py-3 px-4 font-semibold text-slate-300">Количество</th>
                        <th className="text-left py-3 px-4 font-semibold text-slate-300">Последнее обновление</th>
                        <th className="text-right py-3 px-4 font-semibold text-slate-300">Действия</th>
                      </tr>
                    </thead>
                    <tbody>
                      {inventoryQuery.data?.map((item, index) => (
                        <motion.tr
                          key={item.id}
                          initial={{ opacity: 0, x: -20 }}
                          animate={{ opacity: 1, x: 0 }}
                          transition={{ duration: 0.3, delay: index * 0.05 }}
                          className="border-b border-slate-700 hover:bg-slate-700/50 transition-colors"
                        >
                          <td className="py-3 px-4 text-slate-200">{getProductName(item.productId)}</td>
                          <td className="py-3 px-4 text-slate-400">{getWarehouseName(item.warehouseId)}</td>
                          <td className={`py-3 px-4 font-semibold ${getQuantityColor(item.quantity)}`}>
                            {item.quantity} шт
                          </td>
                          <td className="py-3 px-4 text-slate-400">
                            {new Date(item.lastUpdated).toLocaleDateString("ru-RU")}
                          </td>
                          <td className="py-3 px-4 text-right space-x-2">
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => handleOpenDialog(item)}
                              className="text-blue-400 hover:text-blue-300"
                            >
                              <Edit2 className="w-4 h-4" />
                            </Button>
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => handleDelete(item.id)}
                              className="text-red-400 hover:text-red-300"
                            >
                              <Trash2 className="w-4 h-4" />
                            </Button>
                          </td>
                        </motion.tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
            </CardContent>
          </Card>
        </motion.div>
      </div>

      {/* Dialog */}
      <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
        <DialogContent className="bg-slate-800 border-slate-700">
          <DialogHeader>
            <DialogTitle className="text-white">
              {editingId ? "Редактировать запас" : "Добавить запас"}
            </DialogTitle>
            <DialogDescription className="text-slate-400">
              Заполните информацию о запасе
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <Label className="text-slate-300">Продукт</Label>
              <Select value={String(formData.productId)} onValueChange={(v) => setFormData({ ...formData, productId: parseInt(v) })}>
                <SelectTrigger className="bg-slate-700 border-slate-600 text-white">
                  <SelectValue placeholder="Выберите продукт" />
                </SelectTrigger>
                <SelectContent className="bg-slate-700 border-slate-600">
                  {productsQuery.data?.map((product) => (
                    <SelectItem key={product.id} value={String(product.id)} className="text-white">
                      {product.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label className="text-slate-300">Склад</Label>
              <Select value={String(formData.warehouseId)} onValueChange={(v) => setFormData({ ...formData, warehouseId: parseInt(v) })}>
                <SelectTrigger className="bg-slate-700 border-slate-600 text-white">
                  <SelectValue placeholder="Выберите склад" />
                </SelectTrigger>
                <SelectContent className="bg-slate-700 border-slate-600">
                  {warehousesQuery.data?.map((warehouse) => (
                    <SelectItem key={warehouse.id} value={String(warehouse.id)} className="text-white">
                      {warehouse.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label className="text-slate-300">Количество</Label>
              <Input
                type="number"
                value={formData.quantity}
                onChange={(e) => setFormData({ ...formData, quantity: parseInt(e.target.value) || 0 })}
                className="bg-slate-700 border-slate-600 text-white"
                placeholder="0"
              />
            </div>
            <div className="flex gap-3 justify-end">
              <Button variant="outline" onClick={() => setIsDialogOpen(false)}>
                Отмена
              </Button>
              <Button onClick={handleSave} disabled={createMutation.isPending || updateMutation.isPending}>
                {createMutation.isPending || updateMutation.isPending ? (
                  <>
                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                    Сохранение...
                  </>
                ) : (
                  "Сохранить"
                )}
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
